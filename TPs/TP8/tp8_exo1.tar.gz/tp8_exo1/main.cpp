#include "calcul.hh"

int main()
{
    return 0;
}
