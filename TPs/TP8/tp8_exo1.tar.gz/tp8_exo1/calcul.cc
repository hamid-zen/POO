#include "calcul.hh"


calcul::calcul()
    : QWidget(),
      _operande1(new QLineEdit("", this)),
      _operande2(new QLineEdit("", this)),
      _operateur(new QComboBox(this)),
      _resultat(new QLabel("", this)),
      _calculer(new QPushButton("", this)),
      _quitter(new QPushButton("", this))
{}
